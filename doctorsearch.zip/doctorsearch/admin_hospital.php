<title> Insert Hospital </title>
<?php
include 'admin_header.php';
session_start();
  if (!isset($_SESSION['login_user'])) {
    header("location:loginView.php");
}
$que = "SELECT * FROM area ";
$query = "SELECT * FROM location ";
?>

<div class="col-md-2"> </div>
<div class="container-fluid">

    <div class="row form_element">
        <div class="col-md-6">
            <form action="hosinsert.php" method="post">
                <div class="input-group input-group-lg">
                    <span class="input-group-addon" id="sizing-addon1"> Hospital ID </span>
                    <input name="id" type="text" class="form-control" placeholder="id" aria-describedby="sizing-addon1">
                </div>
                <div class="input-group input-group-lg">
                    <span class="input-group-addon" id="sizing-addon1"> Hospital Name </span>
                    <input name="name" type="text" class="form-control" placeholder="name" aria-describedby="sizing-addon1">
                </div>

                <div class="input-group input-group-lg">
                    <span class="input-group-addon" id="sizing-addon1"> Address </span>
                    <input name="address" type="text" class="form-control" placeholder="contact" aria-describedby="sizing-addon1">
                </div>

                <!-- Single button -->			
			 <div class="input-group input-group-lg">
			  <span class="input-group-addon" id="sizing-addon1"> Area </span>
                <?php if ($result = mysqli_query($link, $que)): ?>
                    <select class="form-control" name="area"  type="text">
						<option> Area </option>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
						<option  value="<?php echo $row['areaID'] ?>">  <?php echo $row["loc"] ?>  </option>
                        <?php endwhile; ?>            
                    </select>

                <?php endif; ?>
            </div>    			

                <div class="input-group input-group-lg">
                    <input type="submit" value="submit" class="form-control" placeholder="Username" aria-describedby="sizing-addon1"> 
                </div>

            </form>
        </div>

    </div>
</div>

</body>
</html>