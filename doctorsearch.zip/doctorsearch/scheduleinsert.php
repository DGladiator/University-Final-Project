<title> Schedule </title>

<?php
	include 'admin_header.php';
	$id = $_POST['id'];
	$day = $_POST['day'];
	$start = $_POST['start'];
	$end = $_POST['end'];
	$hos = $_POST['hos'];
	$room = $_POST['room'];
	$res = "INSERT INTO `schedule` (`scheduleNO`, `drID`, `dayNO`, `hospitalID`, `room`, `startTIME`, `endTIME`) 
	VALUES ('', '$id', '$day', '$hos', '$room', '$start', '$end')";	
	$result = mysqli_query($link,$res);
?>
<div class="col-md-2"></div>
<div class="col-md-8"> 
	<div class="container-fluid">
		<div class="jumbotron">
		<?php if (isset($result)): ?>
		<h4> <?php echo "Successfully Inserted"; ?></h4>
		<?php endif; ?>
		</div>
	</div>
</div>
</body>
</html>