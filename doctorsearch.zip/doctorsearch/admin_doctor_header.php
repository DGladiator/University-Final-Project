<!DOCTYPE html>
<?php $link = mysqli_connect("localhost", "root", "", "doctorsearch"); ?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
  </head>
  <body>
    <div class="container">
      <div class="jumbotron">
      	<nav class="nav nav-masthead ">
      	 <div class="col-md-10"> </div>
            <a class="nav-link" href="login.php">Admin Login</a>
        </nav>
        <h1>Doctor Search</h1>
        <p class="lead">Find Your Doctors Here</p>
        <a class="btn btn-lg btn-primary" href="home1.php" role="button">Home &raquo;</a>
      </div>
    </div>
