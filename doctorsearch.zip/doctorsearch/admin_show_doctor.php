<?php
include 'admin_doctor_header.php';
$hosNm = "SELECT * FROM hospital ";
$spCat = "SELECT * FROM specialization ";
$hosLoc = "SELECT * FROM location ";
$statTime = "SELECT * FROM schedule ";
?>

<div class="container-fluid">
    <div class="row form_element">
        <div class="col-md-6">
            <form action="function.php" method="post">
                
                <!-- Specialization  Category -->
                <div class="btn-group">
                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Specialization  Category  <span class="caret"></span>
                    </button>
                    <?php if ($result = mysqli_query( $link, $spCat )):?>
                    
                    <ul class="dropdown-menu">
                        <?php while ($row = mysqli_fetch_assoc($result)):?>
                        <li><a href="#"><?php echo $row["category"] ?></a></li>
                        <?php endwhile;?>
                    </ul>
                    
                    <?php endif;?>
                </div>
                
                <!-- Hospital Location-->
                <div class="btn-group">
                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Hospital Location <span class="caret"></span>
                    </button>
                    <?php if ($result = mysqli_query($link, $hosLoc )):?>
                    
                    <ul class="dropdown-menu">
                        <?php while ($row = mysqli_fetch_assoc($result)):?>
                        <li><a href="#"><?php echo $row["locName"] ?></a></li>
                        <?php endwhile;?>
                    </ul>
                    
                    <?php endif;?>
                </div>
                
                
                <!-- Hospital Name -->
                <div class="btn-group">
                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Hospital Name <span class="caret"></span>
                    </button>
                    <?php if ($result = mysqli_query( $link, $hosNm )):?>
                    
                    <ul class="dropdown-menu">
                        <?php while ($row = mysqli_fetch_assoc($result)):?>
                        <li><a href="#"><?php echo $row["hospitalNAME"] ?></a></li>
                        <?php endwhile;?>
                    </ul>
                    
                    <?php endif;?>
                </div>
                <!-- Start Time -->
                <div class="btn-group">
                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Start Time <span class="caret"></span>
                    </button>
                    <?php if ($result = mysqli_query($link, $statTime )):?>
                    
                    <ul class="dropdown-menu">
                        <?php while ($row = mysqli_fetch_assoc($result)):?>
                        <li><a href="#"><?php echo " Start Time " . " " . $row["startTIME"] ?> <?php echo " -- ". " End Time " .$row["endTIME"] ?></a></li>
                        <?php endwhile;?>
                    </ul>
                    
                    <?php endif;?>
                </div>

                <div class="input-group input-group-lg">
                    <input type="submit" value="submit" class="form-control" placeholder="Username" aria-describedby="sizing-addon1"> 
                </div>

            </form>
        </div>

    </div>
</div>
</body>
</html>