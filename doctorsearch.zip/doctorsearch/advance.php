<title> Doctors Search </title>
<!DOCTYPE html>
<html lang="en">
<br>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
  </head>
  <body>	
      <div class="container">
      <div class="jumbotron">
	  		<nav class="nav nav-masthead ">
				<div class="col-md-11"> </div>
				<a class="nav-link" href = "login.php">Admin Login</a>
            </nav>
        <h1>Doctor Search</h1>
        <p class="lead">Find Your Doctors Here</p>
        <a class="btn btn-lg btn-primary" href="home1.php" role="button">Home &raquo;</a>
		<a class="btn btn-lg btn-primary" href="jquery.php" role="button">Table View  &raquo;</a>
      </div>
    </div>

  </body>
</html>

<?php
    $link = mysqli_connect("localhost", "root", "", "doctorsearch");
    $hosNm = "SELECT * FROM hospital ORDER BY hospital.hospitalNAME ASC";
    $spCat = "SELECT * FROM specialization ";
    $Loc = "SELECT * FROM area ";
    $Day = "SELECT * FROM days ";
?>

<div class="col-md-1"> </div>
<div class="col-md-10 container-fluid">
<div class="jumbotron">
    <form action="advanceoutput.php" method="post">
        <div class="row">
		<div class="col-md-2"> </div>
            <div class="col-md-3">
                <h4> Specialization </h4>
                <?php if ($result = mysqli_query($link, $spCat)): ?>
                    <select class="form-control" name="catData">
                        
						<option value="null"> Select Category => </option>
						
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
						<option  value="<?php echo $row['categoryID'] ?>">  <?php echo $row["category"] ?>  </option>
                        <?php endwhile; ?>            
                    </select>

                <?php endif; ?>
            </div>
            <div class="col-md-1"> </div>
			<div class="col-md-3">
                <h4> Hospital Name </h4>
                <?php if ($result = mysqli_query($link, $hosNm)): ?>
                    <select class="form-control" name="catData1">
					
						<option value="null"> Select Hospital => </option>
                        
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <option  value="<?php echo $row['hospitalID'] ?>">  <?php echo $row["hospitalNAME"] ?>  </option>
                        <?php endwhile; ?>            
                    </select>

                <?php endif; ?>
            </div>
		</div>

		<div class="row">
			
			<div class="col-md-2"> </div>
			    <div class="col-md-3">
                    <h4> Location </h4>
                    <?php if ($result = mysqli_query($link, $Loc)): ?>
                        <select class="form-control" name="catData2">
                            
    						<option value="null"> Select Location => </option>
    						
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
    						<option  value="<?php echo $row['areaID'] ?>">  <?php echo $row["loc"] ?></option>
                            <?php endwhile; ?>            
                        </select>
                    <?php endif; ?>
                </div>
			
				<div class="col-md-1"> </div>
                <div class="col-md-3">
                    <h4> Days </h4>
                    <?php if ($result = mysqli_query($link, $Day)): ?>
                        <select class="form-control" name="catData3">
                            
    						<option value="null"> Select Day => </option>
    						
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
    						<option  value="<?php echo $row['dayNO'] ?>">  <?php echo $row["dayNAME"] ?>  </option>
                            <?php endwhile; ?>            
                        </select>
                    <?php endif; ?>
                </div>

        </div>
		
		<div class="col-md-2"> </div>
        <div class="input-group input-group-lg btn btn-lg">
		<br>
            <input type="submit" value="submit &raquo" name="submit_data"> 
        </div>
    </form>
</div>
</body>
</html>