-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2017 at 05:34 PM
-- Server version: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `doctorsdetector`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminuser`
--

CREATE TABLE `adminuser` (
  `username` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL,
  `id` int(11) NOT NULL,
  `fName` varchar(50) NOT NULL,
  `lName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminuser`
--

INSERT INTO `adminuser` (`username`, `password`, `id`, `fName`, `lName`) VALUES
('robiul', '2580', 1, 'Robiul', 'Hasan'),
('joy', '123', 2, 'Joy', 'Saha'),
('shifat', '123', 3, 'Sarafat', 'Rabby');

-- --------------------------------------------------------

--
-- Table structure for table `area`
--

CREATE TABLE `area` (
  `areaID` int(10) NOT NULL,
  `loc` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `area`
--

INSERT INTO `area` (`areaID`, `loc`) VALUES
(1, 'Dhanmondi'),
(2, 'Mohammadpur'),
(3, 'Gulshan'),
(4, 'Banani'),
(5, 'Motijheel'),
(6, 'Bashundhara'),
(7, 'Shahbagh'),
(8, 'Mirpur');

-- --------------------------------------------------------

--
-- Table structure for table `days`
--

CREATE TABLE `days` (
  `dayNO` int(10) NOT NULL,
  `dayNAME` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `days`
--

INSERT INTO `days` (`dayNO`, `dayNAME`) VALUES
(1, 'Saturday'),
(2, 'Sunday'),
(3, 'Monday'),
(4, 'Tuesday'),
(5, 'Wednesday'),
(6, 'Thursday'),
(7, 'Friday');

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `drID` int(10) NOT NULL,
  `drNAME` varchar(60) DEFAULT NULL,
  `contact` varchar(30) DEFAULT NULL,
  `details` varchar(100) DEFAULT NULL,
  `categoryID` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`drID`, `drNAME`, `contact`, `details`, `categoryID`) VALUES
(0, 'Prof. (Dr.) (Rtd) N.I Khan', '028318135', 'MBBS, MRCP,FRCP', 1),
(1, 'Dr. Mushtaque Ahmed Rana', '', 'Associate Professor, BMCH', 2),
(2, 'Prof. Dr. Md. Azizul Haque', '01818938580', 'Professor & Dept. Head, CMCH', 1),
(3, 'Prof. Dr. M. A. Samad', '10606', 'MBBS, MD(Nephro) FCPS(Medicine), FRCP(Glasgow,UK)', 8),
(4, 'Prof. Dr. Asia Khanam', '10606', 'MBBS, MD(Nephrology)', 8),
(5, 'Dr. K. M. Mamun Murshed', '10606', 'MBBS, PGDND, DLO', 4),
(6, 'Dr. M. Muinul Hafiz', '10606', 'MBBS, DAND, DLO, MS(ENT), FACS(USA), FICS', 4),
(7, 'Brig.Gen. (Rtd) Prof.Dr.Md.Abdul Alim', '10606', 'MBBS(Dhaka), FCPS(Medicine), FACP(USA), FRCP(Glasgow), Senior Fellowship (Singapore)', 1),
(8, 'Prof Dr  Maj Gen Muhammad Rabiul Hossain', '10606', 'MBBS,MCPS,FCPS,FRCP(Edin)', 2),
(9, 'Prof. Dr. Golam Moula Chowdhury', '01711636295', 'MBBS, Ph.D(London), Postdoctoral,Fellow(Japan),\r\nProfessor, Dept. of Urology, BSMMU, Dhaka', 9),
(10, 'DR. A K S ZAHID MAHAMUD KHAN', '10606', 'MBBS(Dhaka),MD(Cardiology)', 5),
(11, 'Dr. Shams Munwar ', '10678', 'MBBS, MRCP (UK), D.Card. (London)', 5),
(12, 'Prof. (Dr.) Md. Shahabuddin Talukder ', '10678', 'MBBS, D.Card. (DU), FCPS (Medicine)', 5),
(13, 'Dr. Saket Aggarwal ', '10678', 'MBBS, MS, DNB (ENT)', 4),
(14, 'Dr. A F M Ekramuddaula', '10678', 'MBBS, FCPS (ENT), MS (Otolaryngology)', 4),
(15, 'Prof. (Dr.) Md. Muzibur Rahman Bhuiyan', '10678', 'MBBS, FCPS (Medicine), MD (Gastroenterology)', 2),
(16, 'Dr. Iqbal Murshed Kabir', '10678', 'MBBS (DMC), FCPS (Medicine), MD (Gastroenterology)', 2),
(17, 'Dr. Fahmida Begum', '10678', 'MBBS, MD (Nephrology)', 8),
(18, 'Dr. Md. Nabiul Hassan', '10678', 'MBBS (DMC), MD (Nephrology)', 8),
(19, 'Dr. Sandip Kumar Dash ', '10678', 'MBBS, MD (Med.), DNB (Med.), DNB (Neurology)', 3),
(20, 'Dr. Amit Goel', '10678', 'MBBS, MS (General Surgery), MCh (Urology)', 9),
(21, 'Dr. M. Zahid Hasan', '10678', 'MBBS, MS(Urology)', 9),
(22, 'Dr. M. Ali', '10678', 'MBBS, MS (Ortho.), Fellow (Sports Medicine)', 11),
(23, 'Dr. Nandkumar Katakdhond', '10678', 'MBBS, MS (Orthopaedics), SICOT Diploma, Fellow Sports Medicine and Joint Replacement, Massachusetts ', 11),
(24, 'Col. (Dr.) Nurun Nahar Fatema', '10606', 'MBBS, FCPS(Pedi), FRCP(Edin), FACC(USA), FSCAI(USA)', 5),
(25, 'DR ABU SALIM', '10606', 'MBBS,D,CARD,MD(CARDIOLOGY),FESC', 5),
(26, 'Dr. AKS Zahid Mahmud khan', '10606', 'MBBS(Dhaka) MD (Cardiology)', 5),
(27, 'Dr. K. M. Mamun Murshed', '10606', 'MBBS, PGDND, DLO', 4),
(28, 'Dr. M. Muinul Hafiz', '10606', 'MBBS, DAND, DLO, MS(ENT), FACS(USA), FICS', 4),
(29, 'Dr. Hasna Fahmima Haque', '10606', 'MBBS, FCPS(Med)', 1),
(30, 'Dr. Md. Robed Amin', '10606', 'MBBS, FCPS(Med)', 1),
(31, 'Prof. (Dr.) Md. Monzur Rahman (Galib)', '10606', 'MBBS, FCPS (Med), WHO Fellow (India)', 1),
(32, 'Dr. Bimal Chandra Shil', '10606', 'MBBS, FCPS(Med), MD(Gastro), Member- ISG(India)', 2),
(33, 'Prof. Dr. Mahmud Hasan', '10606', 'MBBS, PhD (Edin) FCPS, FCPS (Pak) FRCP (Edin), FRCP (Glasgow) ', 2),
(34, 'Prof. (Dr.) Md. Ashraf Ali.', '10606', 'MBBS, FCPS (Med), MD (Neuro), FRCP (Edin)', 3),
(35, 'Prof. (Dr.) Sirajul Haque', '10606', 'MBBS, FCPS (Med), FACP (USA), FRCP (Edin)', 3),
(36, 'Dr. Mamun Al Mahtab (Swapnil)', '10606', 'MBBS, MSC(Gastro,UK), MD(Hepato), FACG(USA), Fellow-OMGE, Hepatology(Japan)', 6),
(37, 'Prof. Dr Faruk Ahmed', '10606', 'MBBS (DMC).MD(HEPATOLOGY)', 6),
(38, 'Dr. kazi Rafiqul Abedin', '10606', 'MBBS, MS(Urology)', 9),
(39, 'Dr. Md. Jahangir Kabir', '10606', 'MBBS, FCPS, FRCS', 9),
(40, 'Dr. Riaz Uddin', '10606', 'MBBS, DDV, MCPS, FCPS ', 10),
(41, 'DR SYED ANWARUZZAMAN', '10606', 'MBBS,MS(Ortho),AO Fellow(GERMANY)', 11),
(42, 'DR. ERFANUL HAQ SIDDIQUI', '10606', 'MBBS(DMC), MS (Ortho),FRSH(London) ', 11),
(43, 'PROF DR. ZIAUL HAQ', '10606', 'MBBS,MS(Ortho)', 11),
(44, 'Prof. Dr. Md. Samsul Arfin', '', 'MBBS, FCPS (Medicine)', 2),
(45, 'Prof Brig General(Retd) Md Bahar Hussain', '', 'MBBS, FCPS (Medicine)', 2),
(46, 'Dr. Md. Ismail Chowdhury', '', 'MBBS, FCPS (Medicine)', 3),
(47, 'Dr. SK. Mahbub Alam', '', 'MBBS, FCPS (Medicine)', 3),
(48, 'PROF. DR. KHAN ABUL KALAM AZAD', '+8809613787801', 'MBBS(DMC), FCPS(MED.), MD(INTERNAM MED.), FACP(USA)', 1),
(49, 'PROF. DR. QUAZI TARIKUL ISLAM', '+8809613787801', 'MBBS, FCPS(MEDICINE), FACP(USA), FRCP(GLASG, UK), FRCP(EDIN)', 1),
(50, 'Prof.Dr. Md. Alauddin Shaikh', '01819247477', 'MBBS, DLO, FAMS(Austria), FICA(USA),  Prof. Dept of  ENT Disease  &  Head neck Surgeon, BMCH', 4),
(51, 'Dr. Afroza Suraya Majumder', '', 'MBBS, DLO, Asst Prof, Dept of ENT, Anwer Khan Medical College & Hospital', 4),
(52, 'Dr. Farhana Afroz', '', 'MBBS, FCPS(Medicine), CCD, Medicine & Diabetes Specialist, BIRDEM.', 1),
(53, 'Dr. A F M Saidur Rahman', '01715055042', 'MBBS, FCPS, D-Card, DTCD, Asst. Prof & R.P BMCH', 1),
(54, 'Dr. Mehran Hossain', '', 'MBBS, DDV(BSMMU), Trained in Aesthetic Surgery (Bangkok,Thailand)', 10),
(55, 'Dr. Shanjina Sharmin', '', 'MBBS(COMC), DDV(DMC), Asst Prof, US-Bangla Medical College & Hospital', 10),
(56, 'Dr. Md. Arif Hossain', '', 'MBBS, MD (Cardiology), BCS (Health), MD (Cardiology)', 5),
(57, 'Dr. Md. Saghir Abdur Rahim', '', 'MBBS, STENO Course on Practical  Diabetology (Kolkata, India)', 8),
(58, 'Dr. A. C. Saha', '01913672742', 'MBBS, D-Ortho, MS (Ortho), A. O (Trauma), A. O (Spine)', 11),
(59, 'Prof. Dr. Golam Faruque', ' 01819220551', 'MBBS, M.S. (Ortho)  Associate Professor, NITOR', 11),
(60, 'Prof. Dr. Md. Ziaul Hoque', ' 01819220551', 'MBBS(Ctg), MRCP(U.K), FRCP(London), Prof, Bangladesh Medical College & Hospital', 1),
(61, 'Dr. Md. Shaheen Wadud', ' 01954225070', 'MBBS, MD (Neurology)', 3),
(62, 'Dr. Md. Abdul Muqueet', '01819403830', 'MBBS, MD (Nephrology)  Assistant Professor Nephrology Dept.', 8),
(63, 'Dr. Hamudur Rahman', '01715115387', 'MBBS, FCPS (Surgery), MS(Urology)', 9),
(64, 'Dr. Md. Aminul Islam', '01556338961', 'M.B.B.S, F.C.P.S (Skin & VD) M.C.P.S (Skin & VD), C.C.D (Diabetics)', 10),
(65, 'Dr. Md. Shahinur Rahman', '01556338961', 'MBBS, DDV  Skin & VD Specialist  (Trained in Sexual Health, Thailand)', 10),
(66, 'Dr. Md. Abdur Razzak', '01747685018', 'MBBS, FCPS (ENT) Nose,Ear, Throat Specialist & Head Neck Surgeon', 4),
(67, 'DR. Md. Farid Uddin Milki', '01762776677', 'MBBS (Karachi), DLO (DU) Consultant (ENT) Bangladesh Medical College & hospital', 4),
(68, 'Dr. Ainul Islam Joarder', '01711624034', 'MBBS,D-Ortho(Nitor), Asst Prof, Orthopaedics & Traumatology Kumudini Medical College & Hospital', 11),
(69, 'Dr. Md. Shahidur Rahman Khan', '01755527561', 'MBBS (DU), BCS (Health), D-Ortho (Nitor) A O Truma (Switzerland)', 11),
(70, 'Dr. Mohammad Zakir Hossain', '029121588', 'MBBS, FCPS (Medicine), MD (Cardiology)', 5),
(71, 'Prof. Dr. Nurul Alam Talukder', '029121588', 'MBBS (DMC), MCPS (Medicine), D. Card', 5),
(72, 'Dr. Mahbubur Rahman Chowdhury', '029121588', 'MBBS, FCPS, Consultant Phaco Surgeon, Chairman, Bangladesh Eye Hospital', 7),
(73, 'Dr. Niaz Abdur-Rahman', '', 'MBBS,DO, MPH(USA)Fellow Vitreo Retina  Consultant Vitreo Retina', 7),
(74, 'Dr. Md. Ali Akbar', '', 'MBBS (DMC), D.O. (DU), MCPS (BCPS), FCPS (BCPS)', 7),
(75, 'Dr. Kamal Haider Khan', '', 'MBBS , DO, MCPS, MS GLAUCOMA SPECIALIST & PHACO SURGEON  BMDC REG. A10671', 7),
(76, 'Prof. (Dr.) A.k.M. Anwarul Islam', '02-9134407', 'MBBS,FCPS,FRCS.', 9),
(77, 'Prof. (Dr.) (Rtd) N.I Khan', '028318135', 'MBBS, MRCP,FRCP', 1),
(78, 'Prof. Brig General(Retd)  DR Azharul Hauque', '0283181654', 'MBBS, MRCP,FRCP,FICS.', 11),
(79, 'DR.A.S.M Kamrul Hasan ', '028319988', 'MBBS, MRCP,FCPS,FRCP', 4),
(80, 'PROF DR.A.U.M Muhsin', '028319988', 'MBBS, MRCP,FCPS,FRCP', 4),
(81, 'Dr.A.H.Hamid Ahmed', '02838478', 'MBBS,MRCP(UK).', 5),
(82, 'Dr. A.B.M Anowar Hossain', '67675577', 'MBBS,FCPS,MS(UK).', 6),
(83, 'Dr.A.B.M Abdullah Harun', '6767578', 'MBBS,FCPS,MS(UK).', 3),
(84, 'Dr. Abu Sayed', '67675756', 'MBBS,FCPS(Edin).', 2),
(85, 'Dr. Abu Sayed khokon', '785469', 'MBBS,FCPS,FRCS.', 3),
(86, 'DR. Afsana begum', '7854636', 'MBBS,FCPS,FRCS.', 4),
(87, 'DR. Anamul Hauque', '7854634', 'MBBS,FCPS,MS(UK).', 6),
(88, 'DR. Tanvir Ahmed', '7854254', 'MBBS,FCPS(Edin).', 10),
(89, 'DR. Sahadat Hossain', '78542254', 'MBBS,FCPS,FRCS.', 11),
(90, 'DR. Shah Ataur Rahman', '785422552', 'MBBS,FCPS,MS(UK).', 1),
(91, 'Asst Prof DR. Suraiya Yeasmin', '7854225525', 'MBBS,FCPS(Edin).', 2),
(92, 'DR. Zahiidul Islam', '7854225', 'MBBS,FCPS(Edin).', 3),
(93, 'DR. Rashed Karim', '85542254', 'MBBS, DAND, DLO, MS(ENT), FACS(USA), FICS', 4),
(94, 'Dr. Rezaul Karim', '855422558', 'MBBS, MS(Urology)', 9),
(95, 'Dr. Md. Ashik Rahman', '855422541', 'MBBS, MD (Cardiology), BCS (Health), MD (Cardiology)', 5);

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE `hospital` (
  `hospitalID` int(10) NOT NULL,
  `hospitalNAME` varchar(40) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `locID` int(10) DEFAULT NULL,
  `areaID` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`hospitalID`, `hospitalNAME`, `address`, `locID`, `areaID`) VALUES
(100, 'Labaid Specialized Hospital', 'House-6, Road-4, Dhanmondi, Dhaka-1205', 1, 1),
(101, 'Popular Diagonstic Center', 'House-11/A, Road-2, Dhanmondi, Dhaka-1205', 2, 1),
(102, 'Bangladesh Medical College Hospital', 'House-32, Road-14A, Dhanmondi, Dhaka-1205', 3, 1),
(103, 'City Hospital', '1/8 Block E, Lalmatia, Shatmasjid Road, Dhaka-1207', 4, 2),
(104, 'Al-Manar Hospital Ltd.', 'Plot: Umo, Block: Rossoi,\r\nSatmosjid Road, Mohammadpur,\r\nDhaka-1207', 5, 2),
(105, 'Bangladesh Eye Hospital', '78 Satmasjid Road, Dhaka, Bangladesh', 0, 1),
(106, 'Comilla Central Hospital', 'Comilla', NULL, 8),
(107, 'Square Hospital Limited', '18/F West , Bir Uttam Qazi, Nuruzzaman Road, Panthapath, Dhaka 1205', 6, 1),
(108, 'Apollo Hospitals Dhaka', 'Block: E, Plot: 81, Bashundhara R/A, Dhaka 1229', 7, 6),
(109, 'Japan Bangladesh Friendship Hospital', '55 Satmasjid Road, Dhaka 1209, Bangladesh', 8, 1),
(110, 'Bangladesh ENT Hospital', '41/A Mirpur Road,, Dhaka 1207, Bangladesh', 9, 2),
(111, 'BIRDEM', '122 Kazi Nazrul Islam Avenue, Shahbagh,Dhaka 1000', 10, 7),
(112, 'United Hospital Limited', 'Road No 71, Dhaka 1212, Bangladesh', 11, 3),
(113, 'Trauma Centre', '22/8/A, Block-B, Mirpur Road Shamoli, Dhaka-1207', 12, 2),
(114, 'Dhaka Shishu Hospital', 'Syed Mahbub Morshed Ave, Dhaka 1207, Bangladesh', 13, 2),
(115, 'Kidney Foundation Bangladesh', '5/2 Mirpur Rd, Dhaka 1216, Bangladesh', 14, 8),
(116, 'Samorita Hospital', '89/1 Pantha Path, Dhaka 1215, Bangladesh', 15, 1);

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `locID` int(10) NOT NULL,
  `locName` varchar(40) DEFAULT NULL,
  `latitude` varchar(10) DEFAULT NULL,
  `longitude` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`locID`, `locName`, `latitude`, `longitude`) VALUES
(0, 'Bangladesh Eye Hospital', '23.751658', '90.367308'),
(1, 'Labaid Specialized Hospital', '23.7419031', '90.3830593'),
(2, 'Popular Diagonstic Center', '23.7718253', '90.3674465'),
(3, 'Bangladesh Medical College Hospital', '23.7503061', '90.3698954'),
(4, 'City Hospital', '23.7540673', '90.3655307'),
(5, 'Al-Manar Hospital Ltd.', '23.7557452', '90.3632181'),
(6, 'Square Hospital Limited', '23.752806', '90.381668'),
(7, 'Apollo Hospitals Dhaka', '23.8099066', '90.4310576'),
(8, 'Japan Bangladesh Friendship Hospital', '23.7395139', '90.3751716'),
(9, 'Bangladesh ENT Hospital', '23.7554196', '90.3761074'),
(10, 'BIRDEM', '23.7393156', '90.3965016'),
(11, 'United Hospital Limited', '23.80456', '90.415611'),
(12, 'Trauma Centre', '23.7720291', '90.3673741'),
(13, 'Dhaka Shishu Hospital', '23.7730713', '90.3688037'),
(14, 'Kidney Foundation Bangladesh', '23.8027242', '90.3603367'),
(15, 'Samorita Hospital', '23.7526869', '90.3850606');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `scheduleNO` int(10) NOT NULL,
  `drID` int(10) DEFAULT NULL,
  `dayNO` int(10) DEFAULT NULL,
  `hospitalID` int(10) DEFAULT NULL,
  `room` varchar(20) DEFAULT NULL,
  `startTIME` varchar(10) DEFAULT NULL,
  `endTIME` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`scheduleNO`, `drID`, `dayNO`, `hospitalID`, `room`, `startTIME`, `endTIME`) VALUES
(1, 1, 1, 102, '405', '10:00am', '02:00pm'),
(2, 2, 1, NULL, '301', '09:00am', '11:00am'),
(3, 3, 1, 100, '406', '09:00am', '08:00pm'),
(4, 4, 1, 100, NULL, '05:30pm', '09:00pm'),
(5, 3, 2, 100, '400', '09:00am', '08:00pm'),
(6, 5, 2, 100, NULL, '05:00pm', '08:00pm '),
(7, 6, 3, 100, NULL, '05:00pm ', '08:00pm '),
(8, 7, 4, 100, NULL, '05:00pm', '08:00pm'),
(9, 8, 3, 100, NULL, '06:00pm', '09:00pm'),
(10, 9, 6, 103, NULL, '09:00am', '11:00am'),
(11, 1, 3, 102, '405', '11:00am', '02:00pm'),
(12, 10, 1, 115, '600', '09:00am', '11:00am'),
(13, 10, 3, 115, '600', '09:00am', '11:00am'),
(14, 12, 3, 108, 'L-6(OPD)', '09:00am', '05:00pm'),
(15, 12, 5, 108, 'L-5(OPD)', '09:00am', '05:00pm'),
(16, 12, 6, 108, 'L-5(OPD)', '09:00am', '05:00pm'),
(17, 11, 4, 108, 'L-5(OPD)', '09:00am', '05:00pm'),
(18, 11, 2, 108, 'L-5(OPD)', '09:00am', '05:00pm'),
(19, 14, 4, 108, 'L-4(OPD)', '09:00AM', '05:00PM'),
(20, 14, 1, 108, 'L-4(OPD)', '09:00AM', '05:00PM'),
(21, 13, 1, 108, 'L-4(OPD)', '09:00am', '05:00pm'),
(22, 13, 3, 108, 'L-4(OPD)', '09:00am', '05:00pm'),
(23, 16, 2, 108, 'L-4(OPD)', '09:00am', '05:00pm'),
(24, 26, 5, 100, '', '05:30pm', '07:30pm'),
(25, 15, 4, 108, 'L-2(OPD)', '09:00am', '05:00pm'),
(26, 17, 2, 108, 'L-8(OPD)', '09:00am', '05:00pm'),
(27, 17, 3, 108, 'L-8(OPD)', '09:00am', '05:00pm'),
(28, 18, 1, 108, 'L-8(OPD)', '09:00am', '05:00pm'),
(29, 18, 2, 108, 'L-8(OPD)', '09:00am', '05:00pm'),
(30, 17, 1, 108, 'L-8(OPD)', '09:00am', '05:00pm'),
(74, 19, 1, 108, 'L-3(OPD)', '09:00am', '05:00pm'),
(75, 19, 4, 108, 'L-3(OPD)', '09:00am', '05:00pm'),
(76, 21, 5, 108, 'L-2(OPD)', '09:00am', '05:00pm'),
(77, 21, 6, 108, 'L-2(OPD)', '09:00am', '05:00pm'),
(78, 20, 1, 108, 'L-2(OPD)', '09:00am', '05:00pm'),
(79, 20, 2, 108, 'L-2(OPD)', '09:00am', '05:00pm'),
(80, 20, 4, 108, 'L-2(OPD)', '09:00am', '05:00pm'),
(81, 23, 1, 108, 'L-1(OPD)', '09:00am', '05:00pm'),
(82, 23, 3, 108, 'L-1(OPD)', '09:00am', '05:00pm'),
(83, 22, 2, 108, 'L-1(OPD)', '09:00am', '05:00pm'),
(84, 22, 4, 108, 'L-1(OPD)', '09:00am', '05:00pm'),
(85, 24, 1, 100, '', '04:00pm', '06:30pm'),
(86, 24, 2, 100, '', '04:00pm', '08:00pm'),
(87, 25, 7, 100, '', '05:30pm', '08:00pm'),
(88, 26, 3, 100, '', '05:30pm', '07:30pm'),
(89, 26, 4, 100, '', '05:30pm', '07:30pm'),
(91, 28, 1, 100, '', '05:00pm', '08:00pm'),
(92, 28, 2, 100, '', '05:00pm', '08:00pm'),
(93, 27, 7, 100, '', '05:00pm', '08:00pm'),
(94, 31, 1, 100, '', '10:00am', '02:00pm'),
(95, 31, 1, 100, '', '04:00pm', '09:00pm'),
(96, 30, 4, 100, '', '05:00pm', '09:00pm'),
(97, 30, 5, 100, '', '05:00pm', '09:00pm'),
(98, 29, 5, 100, '', '04:00pm', '05:30pm'),
(99, 29, 6, 100, '', '04:00pm', '05:30pm'),
(100, 29, 1, 100, '', '04:00pm', '05:30pm'),
(101, 29, 3, 100, '', '04:00pm', '05:30pm'),
(102, 32, 6, 100, '', '05:00pm', '09:00pm'),
(103, 32, 7, 100, '', '05:00pm', '09:00pm'),
(104, 33, 4, 100, '', '04:00pm', '08:00pm'),
(105, 33, 7, 100, '', '04:00pm', '08:00pm'),
(107, 35, 7, 100, '', '09:00am', '07:00pm'),
(108, 34, 1, 100, '', '10:00am', '02:00pm'),
(109, 34, 1, 100, '', '06:00pm', '09:00pm'),
(110, 34, 2, 100, '', '06:00pm', '09:00pm'),
(111, 34, 2, 100, '', '10:00am', '02:00pm'),
(112, 36, 1, 100, '', '06:00pm', '09:30pm'),
(113, 36, 2, 100, '', '06:00pm', '09:30pm'),
(114, 36, 3, 100, '', '06:00pm', '09:30pm'),
(115, 36, 4, 100, '', '06:00pm', '09:30pm'),
(118, 37, 6, 100, '', '04:00pm', '08:00pm'),
(119, 37, 4, 100, '', '08:30pm', '10:00pm'),
(120, 37, 1, 100, '', '08:30pm', '10:00pm'),
(121, 39, 7, 100, '', '10:00am', '02:00pm'),
(122, 39, 1, 100, '', '10:00am', '02:00pm'),
(123, 39, 3, 100, '', '06:00pm', '10:00pm'),
(124, 39, 4, 100, '', '06:00pm', '10:00pm'),
(125, 38, 2, 100, '', '05:00pm', '07:30pm'),
(126, 38, 6, 100, '', '05:00pm', '07:30pm'),
(127, 40, 7, 100, '', '05:00pm', '08:00pm'),
(128, 43, 1, 100, '', '06:00pm', '09:00pm'),
(129, 43, 2, 100, '', '06:00pm', '09:00pm'),
(130, 43, 5, 100, '', '06:00pm', '09:00pm'),
(131, 42, 7, 100, '', '04:00pm', '09:00pm'),
(132, 41, 7, 100, '', '04:00pm', '06:00pm'),
(133, 44, 4, 107, '', '12:00pm', '07:00pm'),
(134, 45, 1, 107, '', '10:00am', '07:30pm'),
(135, 45, 2, 107, '', '10:00am', '07:30pm'),
(136, 45, 5, 107, '', '10:00am', '07:30pm'),
(137, 46, 7, 107, '', '07:00pm', '09:00pm'),
(138, 47, 1, 107, '', '07:30pm', '08:00pm'),
(139, 47, 2, 107, '', '07:30pm', '08:00pm'),
(140, 49, 1, 101, '', '05:00pm', '09:00pm'),
(141, 49, 2, 101, '', '05:00pm', '09:00pm'),
(142, 49, 5, 101, '', '05:00pm', '09:00pm'),
(143, 48, 5, 101, '', '05:00pm', '09:00pm'),
(144, 48, 3, 101, '', '05:00pm', '09:00pm'),
(145, 48, 4, 101, '', '05:00pm', '09:00pm'),
(146, 50, 6, 103, '', '04:00pm', '08:00pm'),
(147, 51, 1, 103, '', '05:00pm', '07:30pm'),
(148, 51, 2, 103, '', '05:00pm', '07:30pm'),
(149, 51, 4, 103, '', '05:00pm', '07:30pm'),
(150, 51, 5, 103, '', '05:00pm', '07:30pm'),
(151, 52, 7, 103, '', '05:00pm', '07:30pm'),
(152, 52, 1, 111, '', '10:00am', '07:30pm'),
(153, 52, 2, 111, '', '10:00am', '07:30pm'),
(154, 53, 6, 103, '', '06:00pm', '08:00pm'),
(155, 53, 7, 102, 'L-4, 410', '02:00pm', '08:00pm'),
(156, 54, 6, 103, '', '07:00pm', '10:00pm'),
(157, 54, 4, 103, 'L-3,303', '07:00pm', '10:00pm'),
(158, 54, 5, 103, 'L-3,303', '07:00pm', '10:00pm'),
(159, 55, 4, 103, 'L-5,510', '06:00pm', '08:00pm'),
(160, 55, 2, 103, 'L-5,510', '06:00pm', '08:00pm'),
(161, 55, 6, 103, 'L-5,510', '06:00pm', '08:00pm'),
(163, 56, 6, 103, 'L-3,310', '05:00pm', '07:00pm'),
(164, 56, 5, 103, 'L-3,310', '05:00pm', '07:00pm'),
(165, 57, 2, 103, '', '08:00pm', '09:30pm'),
(166, 57, 3, 103, '', '08:00pm', '09:30pm'),
(167, 57, 4, 103, '', '08:00pm', '09:30pm'),
(168, 59, 7, 103, 'L-8,202', '05:00pm', '08:00pm'),
(170, 59, 5, 103, 'L-5,204', '02:00pm', '08:00pm'),
(171, 59, 4, 103, 'L-5,204', '02:00pm', '08:00pm'),
(172, 58, 1, 103, 'L-5,204', '02:00pm', '08:00pm'),
(173, 58, 2, 103, 'L-5,204', '02:00pm', '08:00pm'),
(174, 60, 7, 104, 'L-2,205', '04:00pm', '07:30pm'),
(175, 60, 1, 102, 'L-2,205', '04:00pm', '08:00pm'),
(176, 61, 3, 104, 'L-2,205', '10:00am', '01:00pm'),
(177, 61, 4, 104, 'L-2,205', '10:00am', '01:00pm'),
(178, 62, 2, 104, '', '04:00pm', '05:00pm'),
(179, 62, 3, 104, '', '04:00pm', '05:00pm'),
(180, 62, 5, 104, '', '04:00pm', '05:00pm'),
(181, 63, 1, 104, 'L-2,210', '04:00pm', '06:00pm'),
(182, 63, 4, 104, 'L-2,210', '04:00pm', '06:00pm'),
(183, 63, 7, 104, 'L-2,210', '04:00pm', '06:00pm'),
(184, 64, 2, 104, 'L-1,110', '05:00pm', '08:00pm'),
(185, 64, 4, 104, 'L-1,110', '05:00pm', '08:00pm'),
(186, 64, 5, 104, 'L-1,110', '05:00pm', '08:00pm'),
(187, 65, 1, 104, '', '11:00am', '01:00pm'),
(188, 65, 5, 104, '', '11:00am', '01:00pm'),
(189, 66, 1, 104, '', '05:00pm', '07:30pm'),
(190, 66, 6, 104, '', '05:00pm', '07:30pm'),
(191, 67, 2, 104, '', '07:30pm', '09:30pm'),
(192, 67, 6, 104, '', '07:30pm', '09:30pm'),
(193, 68, 1, 104, '', '10:00am', '01:00pm'),
(194, 68, 3, 104, '', '10:00am', '01:00pm'),
(195, 69, 2, 104, 'L-2,202', '05:00pm', '07:00pm'),
(196, 69, 6, 104, 'L-2,202', '05:00pm', '07:00pm'),
(197, 70, 1, 104, 'L-3,305', '07:00pm', '09:00pm'),
(198, 70, 3, 104, 'L-3,305', '07:00pm', '09:00pm'),
(199, 70, 6, 104, 'L-3,305', '07:00pm', '09:00pm'),
(200, 71, 5, 104, '', '06:00pm', '08:30pm'),
(201, 71, 6, 104, '', '06:00pm', '08:30pm'),
(202, 72, 1, 105, 'L-5,510', '10:00am', '05:00pm'),
(203, 72, 2, 105, 'L-5,510', '10:00am', '05:00pm'),
(204, 72, 3, 105, 'L-5,510', '10:00am', '05:00pm'),
(205, 73, 3, 105, 'L-4,410', '10:00am', '02:00pm'),
(206, 73, 4, 105, 'L-4,410', '10:00am', '02:00pm'),
(207, 73, 5, 105, 'L-4,410', '10:00am', '02:00pm'),
(208, 74, 6, 105, 'L-4,410', '10:00am', '04:00pm'),
(209, 74, 7, 105, 'L-4,410', '10:00am', '04:00pm'),
(210, 75, 2, 105, 'L-3,301', '09:00am', '04:00pm'),
(211, 75, 4, 105, 'L-3,301', '09:00am', '04:00pm'),
(212, 76, 1, 109, '405', '10:00am', '11:00am'),
(213, 76, 1, 109, '405', '10:00am', '11:00am'),
(214, 77, 2, 109, '703', '10:00am', '12:00pm'),
(215, 78, 3, 109, '409', '8:00pm', '10:00pm'),
(216, 78, 3, 109, '409', '8:00pm', '10:00pm'),
(217, 79, 4, 109, '605', '8:00pm', '10:00pm'),
(218, 80, 5, 109, '602', '9:00pm', '11:00pm'),
(219, 81, 6, 109, '509', '7:00pm', '10:00pm'),
(220, 82, 7, 112, '302', '7:00pm', '9:00pm'),
(222, 84, 1, 112, '203', '10:00am', '12:00pm'),
(223, 85, 3, 112, '301', '8:00pm', '10:00pm'),
(224, 86, 3, 112, '420', '8:00pm', '10:00pm'),
(225, 87, 4, 112, '405', '10:00am', '12:00pm'),
(226, 87, 5, 112, '203', '10:00am', '12:00am'),
(227, 88, 6, 112, '302', '10:00am', '12:00am'),
(228, 89, 7, 112, '401', '8:00pm', '11:00pm'),
(229, 90, 1, 116, '245', '10:00am', '12:00am'),
(230, 91, 3, 116, '201', '8:00pm', '10:00pm'),
(231, 92, 6, 116, '203', '10:00am', '12:00am'),
(232, 93, 5, 116, '120', '10:00am', '12:00am'),
(233, 93, 7, 110, '120', '11:00am', '09:00pm'),
(234, 94, 3, 116, '203', '10:00am', '9:00pm'),
(235, 94, 2, 114, '203', '10:00am', '9:00pm'),
(236, 95, 4, 113, '201', '10:00am', '12:00pm'),
(237, 95, 5, 113, '201', '10:00am', '12:00pm');

-- --------------------------------------------------------

--
-- Table structure for table `specialization`
--

CREATE TABLE `specialization` (
  `categoryID` int(11) NOT NULL,
  `category` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `specialization`
--

INSERT INTO `specialization` (`categoryID`, `category`) VALUES
(1, 'Medicine'),
(2, 'Gestroenterology'),
(3, 'Neurology'),
(4, 'ENT'),
(5, 'Cardiology'),
(6, 'Hepatology'),
(7, 'Eye Specialist'),
(8, 'Nephrology'),
(9, 'Urology'),
(10, 'Skin & VD'),
(11, 'Orthopedic');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminuser`
--
ALTER TABLE `adminuser`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `area`
--
ALTER TABLE `area`
  ADD PRIMARY KEY (`areaID`);

--
-- Indexes for table `days`
--
ALTER TABLE `days`
  ADD PRIMARY KEY (`dayNO`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`drID`),
  ADD KEY `categoryID` (`categoryID`);

--
-- Indexes for table `hospital`
--
ALTER TABLE `hospital`
  ADD PRIMARY KEY (`hospitalID`),
  ADD KEY `locID` (`locID`),
  ADD KEY `areaID` (`areaID`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`locID`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`scheduleNO`),
  ADD KEY `drID` (`drID`),
  ADD KEY `dayNO` (`dayNO`),
  ADD KEY `hospitalID` (`hospitalID`);

--
-- Indexes for table `specialization`
--
ALTER TABLE `specialization`
  ADD PRIMARY KEY (`categoryID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminuser`
--
ALTER TABLE `adminuser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `area`
--
ALTER TABLE `area`
  MODIFY `areaID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `scheduleNO` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=238;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `doctors`
--
ALTER TABLE `doctors`
  ADD CONSTRAINT `doctors_ibfk_2` FOREIGN KEY (`categoryID`) REFERENCES `specialization` (`categoryID`);

--
-- Constraints for table `hospital`
--
ALTER TABLE `hospital`
  ADD CONSTRAINT `hospital_ibfk_1` FOREIGN KEY (`locID`) REFERENCES `location` (`locID`),
  ADD CONSTRAINT `hospital_ibfk_2` FOREIGN KEY (`areaID`) REFERENCES `area` (`areaID`);

--
-- Constraints for table `schedule`
--
ALTER TABLE `schedule`
  ADD CONSTRAINT `schedule_ibfk_1` FOREIGN KEY (`drID`) REFERENCES `doctors` (`drID`),
  ADD CONSTRAINT `schedule_ibfk_2` FOREIGN KEY (`dayNO`) REFERENCES `days` (`dayNO`),
  ADD CONSTRAINT `schedule_ibfk_3` FOREIGN KEY (`hospitalID`) REFERENCES `hospital` (`hospitalID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
