<title>Location Insert</title>
<?php
    include 'admin_header.php';
    session_start();
    if (!isset($_SESSION['login_user'])) {
        header("location:loginView.php");
    }
    $query = "SELECT * FROM doctors ";
    $query1 = "SELECT * FROM days ";
    $query2 = "SELECT * FROM hospital ";
?>
<div class="col-md-2"> </div>
<div class="container-fluid">
    <div class="row form_element">
        <div class="col-md-6">
            <form action="locationinsert.php" method="post">   
                <div class="input-group input-group-lg">
                    <span class="input-group-addon" id="sizing-addon1"> Location ID </span>
                    <input name="id" type="text" class="form-control" placeholder="id" aria-describedby="sizing-addon1">
                </div>
                <div class="input-group input-group-lg">
                    <span class="input-group-addon" id="sizing-addon1"> Location </span>
                    <input name="loc" type="text" class="form-control" placeholder="location" aria-describedby="sizing-addon1">
                </div>
				<div class="input-group input-group-lg">
                    <span class="input-group-addon" id="sizing-addon1"> Latitude </span>
                    <input name="Latitude" type="text" class="form-control" placeholder="latitude" aria-describedby="sizing-addon1">
                </div>
				<div class="input-group input-group-lg">
                    <span class="input-group-addon" id="sizing-addon1"> Longitude </span>
                    <input name="Longitude" type="text" class="form-control" placeholder="longitude" aria-describedby="sizing-addon1">
                </div>
                <div class="input-group input-group-lg">
                    <input type="submit" value="submit" class="form-control" placeholder="Username" aria-describedby="sizing-addon1"> 
                </div>
            </form>
        </div>
    </div>
</div>
<br>
<div class="col-md-8"> </div>
<div class="col-md-4">
    <a href = "logout.php">Sign Out</a>
</div>
</body>
</html>