<title> Doctor Insert </title>
<?php
	include 'admin_header.php';
	$id = $_POST['id'];
	$name = $_POST['name'];
	$contact = $_POST['contact'];
	$details = $_POST['details'];
	$cat = $_POST['cat'];
	$query = "INSERT INTO `doctors` (`drID`, `drNAME`, `contact`, `details`,`categoryID`) VALUES ('$id', '$name','$contact','$details','$cat')";	
	$result = mysqli_query($link, $query);
?>
<div class="col-md-2"></div>
<div class="col-md-8"> 
	<div class="container-fluid">
		<div class="jumbotron">
			<?php if (isset($result)): ?>
			<h4><?php echo "Successfully Inserted"; ?></h4>	
			<?php endif; ?>
		</div>
	</div>
</div>
</body>
</html>