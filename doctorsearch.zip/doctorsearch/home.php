<title> Home </title>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Bootstrap -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
        <div class="container">
    		<div class="jumbotron">
    	  		<nav class="nav nav-masthead ">
    				<div class="col-md-10"> </div>
                    <a class="nav-link" href="login.php">Admin Login</a>
                </nav>
            <h1>Doctors Detector</h1>
            <p class="lead">Find Your Doctors Here</p>
            <a class="btn btn-lg btn-primary" href="experiment.php" role="button">Search Now &raquo;</a>
    		</div>
        </div>
    	<div class="col-md-8">
    		<img src="doctors.svg" alt="Mountain View" style="width:1404px;height:290px;">
		</div>
	</body>
</html>