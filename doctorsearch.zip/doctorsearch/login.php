<?php
   $db = mysqli_connect("localhost", "root", "", "doctorsearch");
   session_start();
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      $myusername = mysqli_real_escape_string($db,$_POST['username']);
      $mypassword = mysqli_real_escape_string($db,$_POST['password']); 
      $sql = "SELECT id FROM adminUser WHERE username = '$myusername' and password = '$mypassword'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $count = mysqli_num_rows($result);
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
         $_SESSION['login_user'] = $myusername;
         header("location: welcome.php");
      }
      else {
         echo $error = "Login Name or Password is invalid";
         header("location: loginView.php");
      }
   }
  if (!isset($_SESSION['login_user'])) {
    header("location:loginView.php");
}
     elseif(isset($_SESSION['login_user'])) {
    header("location:welcome.php");
}
?>