<title>Specialization Insert</title>
<?php
    include 'admin_header.php';
    session_start();
    if (!isset($_SESSION['login_user'])) {
        header("location:loginView.php");
    }
?>
<div class="container">
	 <div class="row">
		  <div class="col-md-6 test">  
			<form action="specializationin.php" method="post">  
				  <input type="text" class="form-control" name="category" placeholder="Specialization category" aria-describedby="basic-addon1">
			  <input type="text" class="form-control" name="id" placeholder="Doctor's ID" aria-describedby="basic-addon1">
			  <input type="submit" value="submit"> 
		   </form>
		  </div>
	</div>
</div>
</body>
</html>