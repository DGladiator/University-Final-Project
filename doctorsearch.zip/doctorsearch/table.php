<title> Doctors list </title>
<?php
	include 'admin_doctor_header.php';
	$catRes = $_POST['catData'];
	$catRes1 = $_POST['catData1'];
	$catRes2 = $_POST['catData2'];
	$catRes3 = $_POST['catData3'];
?>
<?php if($_POST['catData'] === "null" && $_POST['catData1'] === "null" && $_POST['catData2'] === "null" && $_POST['catData3'] === "null"): ?> 
		<?php $query = "SELECT DISTINCT hospitalNAME FROM hospital where 1"; ?>
		<div class="col-md-3"></div>
		<div class="col-md-6">
            <table class="table table-striped table-bordered  table-responsive">
				<?php $result = mysqli_query($link, $query); ?>
			    <tr>
                    <th style=" text-align: center"> Hospital Name </th>
                </tr>
				<tr>			
					<?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <td style=" text-align: center">
					<?php echo $row['hospitalNAME'];?> <a href="pass.php?link=<?php echo $row['hospitalNAME'];?>"> See More </a>
					</td>
                </tr>
					<?php endwhile; ?>
            </table>
        </div>
				<?php endif; ?>
</body>
</html>