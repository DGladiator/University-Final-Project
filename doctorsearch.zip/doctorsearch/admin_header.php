<!DOCTYPE html>
<?php $link = mysqli_connect("localhost", "root", "", "doctorsearch"); ?>
<html lang="en">
	<head>
		<?php $link = mysqli_connect("localhost", "root", "", "doctorsearch"); ?>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- Bootstrap -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
	
	</head>
	<body>
		<div class="container">
			<div class="jumbotron">
				<nav class="nav nav-masthead ">
					<div class="col-md-10"> </div>
					<a class="nav-link" href = "home1.php">Home</a>
					<a class="nav-link" href = "logout.php">Sign Out</a>
				</nav>
				<h1>Doctor Search</h1>
				<p class="lead">Find Your Doctors Here</p>
				<a class="btn btn-lg btn-primary" href="advance.php" role="button">Advance Search &raquo;</a>
				<a class="btn btn-lg btn-primary" href="jquery.php" role="button"> Search  &raquo&raquo;</a>
			</div>
		</div>