<title> Update Doctors </title>
<?php
include 'admin_header.php';
session_start();
  if (!isset($_SESSION['login_user'])) {
    header("location:loginView.php");
}
$query = "SELECT * FROM doctors ";
?>
<div class="col-md-2"> </div>
<div class="container-fluid">
    <div class="row form_element">
        <div class="col-md-6">
            <form action="ins.php" method="post">
                <div class="input-group input-group-lg">
                    <span class="input-group-addon" id="sizing-addon1"> Doctor ID </span>
                    <input name="id" type="text" class="form-control" placeholder="id" aria-describedby="sizing-addon1">
                </div>
                <div class="input-group input-group-lg">
                    <span class="input-group-addon" id="sizing-addon1"> Doctor Name </span>
                    <input name="name" type="text" class="form-control" placeholder="name" aria-describedby="sizing-addon1">
                </div>

                <div class="input-group input-group-lg">
                    <span class="input-group-addon" id="sizing-addon1"> Contact </span>
                    <input name="contact" type="text" class="form-control" placeholder="contact" aria-describedby="sizing-addon1">
                </div>

                <div class="input-group input-group-lg">
                    <span class="input-group-addon" id="sizing-addon1"> Details </span>
                    <input name="details" type="text" class="form-control" placeholder="details" aria-describedby="sizing-addon1">
                </div>

                <!-- Single button -->
              <div class="input-group input-group-lg">
			  <span class="input-group-addon" id="sizing-addon1"> Category </span>
                <?php if ($result = mysqli_query($link, $query)): ?>
                    <select class="form-control" name="cat"  type="text">
						<option> Category </option>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
						<option  value="<?php echo $row['categoryID'] ?>">  <?php echo $row["category"] ?>  </option>
                        <?php endwhile; ?>            
                    </select>

                <?php endif; ?>
            </div>    
                <div class="input-group input-group-lg">
                    <input type="submit" value="submit" class="form-control" placeholder="Username" aria-describedby="sizing-addon1"> 
                </div>

            </form>
        </div>

    </div>
</div>
</body>
</html>