<?php
	$link = mysqli_connect("localhost", "root", "", "doctorsearch");
	$category = $_POST['category'];
	$id = $_POST['id'];
	$result = mysqli_query($link,"INSERT INTO specialization(category,drID) VALUES ('$category', '$id')");
?>