<title> Doctors Search </title>
<?php
    include 'admin_doctor_header.php';
    $hosNm = "SELECT * FROM hospital ";
    $spCat = "SELECT * FROM specialization ";
    $Loc = "SELECT * FROM area ";
    $Day = "SELECT * FROM days ";
?>

<div class="col-md-2"> </div>
<div class="col-md-8 container-fluid">
    <div class="jumbotron">
        <form action="robiul.php" method="post">
            <div class="row">
                <div class="col-md-2"> </div>
                <div class="col-md-3">
                    <h4> Specialization Category </h4>
                    <?php if ($result = mysqli_query($link, $spCat)): ?>
                        <select class="form-control" name="catData">
    						<option value="null"> Select Category => </option>
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
    						<option  value="<?php echo $row['categoryID'] ?>">  <?php echo $row["category"] ?>  </option>
                            <?php endwhile; ?>            
                        </select>
                    <?php endif; ?>
                </div>
    			
    			<div class="col-md-3">
                    <h4> Hospital Name </h4>
                    <?php if ($result = mysqli_query($link, $hosNm)): ?>
                        <select class="form-control" name="catData1">
    						<option value="null"> Select Hospital => </option>
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <option  value="<?php echo $row['hospitalID'] ?>">  <?php echo $row["hospitalNAME"] ?>  </option>
                            <?php endwhile; ?>            
                        </select>
                    <?php endif; ?>
                </div>
    		</div>
    		<div class="row">
    			<div class="col-md-2"> </div>
    			<div class="col-md-3">
                    <h4> Location </h4>
                    <?php if ($result = mysqli_query($link, $Loc)): ?>
                        <select class="form-control" name="catData2">
    						<option value="null"> Select Location => </option>
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
    						<option  value="<?php echo $row['areaID'] ?>">  <?php echo $row["loc"] ?>  </option>
                            <?php endwhile; ?>            
                        </select>
                    <?php endif; ?>
                </div>
    			<div class="col-md-3">
                    <h4> Days </h4>
                    <?php if ($result = mysqli_query($link, $Day)): ?>
                        <select class="form-control" name="catData3">
    						<option value="null"> Select Day => </option>
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
    						<option  value="<?php echo $row['dayNO'] ?>">  <?php echo $row["dayNAME"] ?>  </option>
                            <?php endwhile; ?>            
                        </select>
                    <?php endif; ?>
                </div>
            </div>
    		<div class="col-md-2"> </div>
            <div class="input-group input-group-lg btn btn-lg">
                <br>
                <input type="submit" value="submit &raquo" name="submit_data"> 
            </div>
        </form>
    </div>
</div>
</body>
</html>