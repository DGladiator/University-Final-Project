<?php
	include 'admin_header.php';
	$id = $_POST['id'];
	$name = $_POST['loc'];
	$Latitude = $_POST['Latitude'];
	$Longitude = $_POST['Longitude'];
	$query = "INSERT INTO `location` (`locID`, `locNAME`, `latitude`, `longitude`) VALUES ('$id', '$name','$Latitude','$Longitude')";
	$result = mysqli_query($link, $query);
?>
<div class="col-md-2"></div>
<div class="col-md-8"> 
	<div class="container-fluid">
		<div class="jumbotron">
			<?php if (isset($result)): ?>
			<h4> <?php echo "Successfully Inserted"; ?></h4>
			<?php endif; ?>
		</div>
	</div>
</div>
</body>
</html>