<title> Table View </title>
<?php $link = mysqli_connect("localhost", "root", "", "doctorsearch"); ?>
<!DOCTYPE html>
<html lang="en">
<br>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel= "stylesheet" href="//cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
  </head>
  <body>
		
      <div class="container">
      <div class="jumbotron">
	  		<nav class="nav nav-masthead ">
				<div class="col-md-11"> </div>
				<a class="nav-link" href = "login.php">Admin Login</a>
            </nav>
        <h1>Doctor Search</h1>
        <p class="lead">Find Your Doctors Here</p>
        <a class="btn btn-lg btn-primary" href="home1.php" role="button">Home &raquo;</a>
		<a class="btn btn-lg btn-primary" href="experiment.php" role="button">Advance Search  &raquo;</a>
      </div>
    </div>

<?php
$query = "SELECT DISTINCT doctors.drNAME, schedule.startTIME, schedule.endTIME, schedule.room, days.dayNAME,
hospital.hospitalNAME, area.loc FROM doctors,days,schedule,hospital,area where doctors.drID=schedule.drID AND
hospital.hospitalID=schedule.hospitalID AND days.dayNO=schedule.dayNO AND hospital.areaID=area.areaID";
$result = mysqli_query($link, $query);
?>

<div class="col-md-1"> </div>
<div class="col-md-10"> 
<table id="example" class="table table-striped table-bordered table-hover table-responsive" cellspacing="0" width="100%">
</div>
<?php $result = mysqli_query($link, $query); ?> <br>
    <thead>
      <tr>
       <th style=" text-align: center"> Name </th>
       <th style=" text-align: center"> Hospital </th>
       <th style=" text-align: center"> Location </th>
       <th style=" text-align: center"> Days </th>
       <th style=" text-align: center"> Start time </th>
       <th style=" text-align: center"> Room </th>
     </tr>
    </thead>
    <tbody>         
      <tr>
        <?php while ($row = mysqli_fetch_assoc($result)):?>	
        <td><a href="pass.php?link=<?php echo $row['drNAME'];?>"><?php echo $row['drNAME'];?></a></td>
        <td><a href="maps.php?link=<?php echo $row['hospitalNAME'];?>"><?php echo $row['hospitalNAME'];?></a></td>
        <td><?php echo $row["loc"];?></td>
        <td><?php echo $row["dayNAME"];?></td>
        <td><?php echo $row["startTIME"];?></td>
        <td><?php echo $row["room"];?></td>
      </tr>
        <?php endwhile;?>
  </tbody>
</table> 
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
<script>
$(document).ready(function(){
    $('#example').DataTable();
});
</script>
</body>
</html>