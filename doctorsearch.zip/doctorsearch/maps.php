<title> Google Maps </title>
<?php
 include 'admin_doctor_header.php';
$hos = $_GET['link'];
$query = "SELECT latitude,longitude FROM location,hospital WHERE location.locID=hospital.locID AND hospitalNAME= '$hos'";
?>
<?php
    $result = mysqli_query($link,$query);
    while ($row = mysqli_fetch_assoc($result)) {
      $latitude = $row['latitude'];
      $longitude = $row['longitude'];
    }
?>
<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="/maps/documentation/javascript/demos/demos.css">
    <style>
      #map {
        height: 400px;
		margin: auto;
        width: 80%;
       }
	</style>
  </head>
  <body >
    <div id="map"></div>
        <script> 
          function initMap() {
            var uluru = {lat: <?php print_r($latitude);?>, lng: <?php print_r($longitude);?>};
            var map = new google.maps.Map(document.getElementById('map'), {
            zoom: 18,
            center: uluru
          });
          var marker = new google.maps.Marker({
            position: uluru,
            map: map
            });
          }
    </script> 
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBLIT--pz9XLPXxfJF1u7P6TdlfGzlsRXI&callback=initMap"
    async defer>
    </script>
  </body>
</html>