<title> Admin Panel </title>
<?php
	include 'admin_header.php';
	session_start();
	if (!isset($_SESSION['login_user'])) {
	    header("location:loginView.php");
	}
	$user_check = $_SESSION['login_user'];
	$ses_sql = mysqli_query($link, "select * from adminUser where username = '$user_check' ");
	$row = mysqli_fetch_array($ses_sql, MYSQLI_ASSOC);
	$login_session = $row['fName'] . " " . $row['lName'];
?>
<div class="col-md-1"></div>
<div class="col-md-10"> 
	<div class="container-fluid">
    	<div class="jumbotron">
    		<div class="row"> 
			<div class="col-md-2"></div>
        	<div class="col-md-4">
        		Welcome <b><?php echo $login_session; ?> </b>
			</div>
	</div>
	</div>
</div> 
<div class="col-md-1"></div>
<div class="container-fluid">
    <div class="jumbotron">
		<div id="navbar-example">
			<ul class="nav nav-tabs" role="tablist">
			<div class="col-md-1"></div>
				<li><a href="admin_doctor.php">Add doctors</a></li>
                <li><a href="admin_hospital.php">Add Hospital</a></li>
                <li><a href="location.php">Add Location</a></li>
				<li><a href="admin_sche.php">Add Schedule</a></li>
				<li><a href="update_sche.php">Update Schedule</a></li>	
			</ul>
		</div>
  	</div>
</div>
</body>
</html>
