<?php
include 'admin_doctor_header.php';
session_start();
if (isset($_SESSION['login_user'])) {
    header("location:welcome.php");
}
?>
<div class="col-md-2"></div>
<div class="col-md-8 container-fluid">
    <div class="jumbotron"> 
	   <div class="col-md-2"></div>	
        <div class="row">
            <div class="col-md-6 loginForm">
                <form action="login.php" method="post">
                    <div class="form-group">
                        <label for="exampleInputEmail1"> User Name </label>
                        <input type="text" class="form-control" id="exampleInputEmail1" placeholder=" User Name " name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1"> Password </label>
                        <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-default"> Submit </button>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>