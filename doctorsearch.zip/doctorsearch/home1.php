<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- Bootstrap -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
		<title> Home </title>
	</head>
	<body>
      <div class="container">
      <div class="jumbotron">
	  		<nav class="nav nav-masthead ">
				<div class="col-md-11"> </div>
                <a class="nav-link" href="login.php">Admin Login</a>
            </nav>
        <h1>Doctor Search</h1> 
        <p class="lead">Find Your Doctors Here</p> <br>
		
        <a class="btn btn-lg btn-primary" href="advance.php" role="button">Advance Search &raquo;</a>
        <a class="btn btn-lg btn-primary" href="jquery.php" role="button">Search  &raquo;</a>
      </div>
    </div>
	<img src="doctors.svg" alt="Mountain View" style="width:1404px;height:290px;">
	</body>
</html>