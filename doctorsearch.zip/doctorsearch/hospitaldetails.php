<title> Hospital </title>
<?php
	include 'admin_doctor_header.php';
	$num = $_GET['link'];
	$query = "SELECT hospitalNAME,address,loc from hospital,area where area.areaID=hospital.areaID AND hospitalNAME = '$num'";
	$result = mysqli_query($link, $query);
?>
<br>
<div class="col-md-2"> </div>
	<div class="col-md-8">
        <table class="table table-striped table-bordered table-hover table-responsive">
		 <?php $result = mysqli_query($link, $query); ?> <br>
            <tr>
				<th style=" text-align: center"> Hospital Name </th>
				<th style=" text-align: center"> Address </th>
				<th style=" text-align: center"> Location </th>
            </tr>
            <tr>
			<?php while ($row = mysqli_fetch_assoc($result)):?>	
				<td><?php echo $row["hospitalNAME"];?></td>
				<td><?php echo $row["address"];?></td>
				<td><?php echo $row["loc"];?></td>
            </tr>
            <?php endwhile;?>
        </table>
    </div>
</body>
</html>