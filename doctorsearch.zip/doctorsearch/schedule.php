<?php
	include 'admin_doctor_header.php';
	$num = $_GET['link'];
	$query = "SELECT DISTINCT startTIME,endTIME,dayNAME,hospitalNAME,room,loc,scheduleNO FROM doctors,days,schedule,hospital,area where schedule.drID=doctors.drID AND
	days.dayNO= schedule.dayNO AND hospital.hospitalID=schedule.hospitalID  AND hospital.areaID=area.areaID AND  drNAME = '$num'";
	$result = mysqli_query($link, $query);
?>
<br>
<div class="col-md-2"> </div>
	<div class="col-md-8">
		<table class="table table-striped table-bordered table-hover table-responsive">
			<?php $result = mysqli_query($link, $query); ?> <br>
			<tr>
				<th style=" text-align: center"> Days </th>
				<th style=" text-align: center"> Start time </th>
				<th style=" text-align: center"> End time </th>
				<th style=" text-align: center"> Hospital </th>
				<th style=" text-align: center"> Room </th>
				<th style=" text-align: center"> Location </th>
				<th style=" text-align: center"> Update </th>
			</tr>
			<tr>
			<?php while ($row = mysqli_fetch_assoc($result)):?>	
				<td><?php echo $row["dayNAME"];?></td>
				<td><?php echo $row["startTIME"];?></td>
				<td><?php echo $row["endTIME"];?></td>
				<td><a href="maps.php?link=<?php echo $row['hospitalNAME'];?>"><?php echo $row['hospitalNAME'];?></a></td>
				<td><?php echo $row["room"];?></td>
				<td><?php echo $row["loc"];?></td>
				<td style=" text-align: center"><a href="update_sche.php?link=<?php echo $row['scheduleNO'];?>"> Edit </a></td>
			</tr>
			<?php endwhile;?>
		</table>
	</div>
</body>
</html>