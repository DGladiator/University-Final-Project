<title> Doctors list </title>
<?php
	include 'admin_doctor_header.php';
	$link = mysqli_connect("localhost", "root", "", "doctorsearch");
	$catRes = $_POST['catData'];
	$catRes1 = $_POST['catData1'];
	$catRes2 = $_POST['catData2'];
	$catRes3 = $_POST['catData3'];

	if($_POST['catData'] === "null" && $_POST['catData1'] === "null" && $_POST['catData2'] === "null" && $_POST['catData3'] === "null")
		{
			$query = "SELECT DISTINCT drNAME FROM doctors WHERE 1 ";
		}
	elseif($_POST['catData1'] === "null" && $_POST['catData2'] == "null" && $_POST['catData3'] === "null")
		{
			$query = "SELECT DISTINCT drNAME FROM doctors, specialization, hospital, area, schedule WHERE 
					specialization.categoryID= doctors.categoryID AND specialization.categoryID = '$catRes'";
		}
	elseif($_POST['catData'] === "null" && $_POST['catData2'] == "null" && $_POST['catData3'] === "null")
		{
			$query = "SELECT DISTINCT drNAME FROM doctors, specialization, hospital, area, schedule WHERE
								schedule.drID= doctors.drID AND schedule.hospitalID ='$catRes1'";
		}
	elseif($_POST['catData'] === "null" && $_POST['catData1'] == "null" && $_POST['catData3'] === "null")
		{
			$query = "SELECT DISTINCT drNAME FROM doctors, hospital, area, schedule WHERE area.areaID=hospital.areaID
					AND hospital.hospitalID=schedule.hospitalID AND schedule.drID=doctors.drID AND area.areaID= '$catRes2'";
		}
	elseif($_POST['catData'] === "null" && $_POST['catData1'] == "null" && $_POST['catData2'] === "null")
		{
			$query = "SELECT DISTINCT drNAME FROM doctors, days, schedule WHERE
						days.dayNO=schedule.dayNO AND schedule.drID=doctors.drID AND days.dayNO= '$catRes3'";
		}
	elseif($_POST['catData2'] === "null" && $_POST['catData3'] === "null")
	{
		$query = "SELECT DISTINCT drNAME FROM doctors, specialization, schedule WHERE 
				specialization.categoryID= doctors.categoryID AND specialization.categoryID = '$catRes' 
				and schedule.drID= doctors.drID AND schedule.hospitalID ='$catRes1'";
	}
	elseif($_POST['catData1'] === "null" && $_POST['catData3'] === "null")
		{
			$query = "SELECT DISTINCT drNAME FROM doctors, specialization,hospital, schedule WHERE 
				specialization.categoryID= doctors.categoryID AND specialization.categoryID = '$catRes' and
				schedule.drID= doctors.drID AND schedule.hospitalID=hospital.hospitalID AND hospital.areaID='$catRes2'";
		}

	elseif($_POST['catData1'] === "null" && $_POST['catData2'] === "null")
		{
			$query = "SELECT DISTINCT drNAME FROM doctors, specialization,days, schedule WHERE 
					specialization.categoryID= doctors.categoryID AND specialization.categoryID='$catRes'
					and  schedule.drID= doctors.drID AND schedule.dayNO=days.dayNO AND days.dayNO='$catRes3'";
		}

	elseif($_POST['catData'] === "null" && $_POST['catData1'] === "null")
		{
			$query = "SELECT DISTINCT drNAME FROM doctors,hospital,days,area, schedule WHERE 
					hospital.areaID=area.areaID AND schedule.hospitalID=hospital.hospitalID AND area.areaID='$catRes2'
					and  schedule.drID= doctors.drID AND schedule.dayNO=days.dayNO AND days.dayNO='$catRes3'";
		}
	elseif($_POST['catData'] === "null" && $_POST['catData3'] === "null")
		{
			$query = "SELECT DISTINCT drNAME FROM doctors,hospital,area, schedule WHERE 
				schedule.hospitalID=hospital.hospitalID AND schedule.hospitalID='$catRes1' and
				schedule.drID= doctors.drID AND area.areaID=hospital.areaID AND area.areaID='$catRes2'";
		}
	elseif($_POST['catData'] === "null" && $_POST['catData2'] === "null")
		{
		$query = "SELECT DISTINCT drNAME FROM doctors,hospital,days,area, schedule WHERE 
					schedule.hospitalID=hospital.hospitalID AND schedule.hospitalID='$catRes1' and
					schedule.drID= doctors.drID AND schedule.dayNO=days.dayNO AND days.dayNO='$catRes3'";
		}
	elseif($_POST['catData3'] === "null")
		{
			$query = "SELECT DISTINCT drNAME FROM doctors, specialization, area, hospital, schedule WHERE 
					specialization.categoryID= doctors.categoryID AND specialization.categoryID = '$catRes' and
					schedule.drID= doctors.drID AND schedule.hospitalID ='$catRes1' AND area.areaID=hospital.areaID AND
					hospital.hospitalID=schedule.hospitalID AND schedule.drID=doctors.drID AND area.areaID='$catRes2'";
		}
	elseif($_POST['catData2'] === "null")
		{
			$query = "SELECT DISTINCT drNAME FROM doctors, specialization, area, hospital, schedule WHERE 
					specialization.categoryID= doctors.categoryID AND specialization.categoryID = '$catRes' and 
					schedule.drID= doctors.drID AND schedule.hospitalID ='$catRes1' AND area.areaID=hospital.areaID AND
					hospital.hospitalID=schedule.hospitalID AND schedule.drID=doctors.drID AND schedule.dayNO='$catRes3' ";
		}
	elseif($_POST['catData1'] === "null")
		{
			$query = "SELECT DISTINCT drNAME FROM doctors, specialization, area, hospital, schedule WHERE 
					specialization.categoryID= doctors.categoryID AND specialization.categoryID ='$catRes' and
					schedule.drID= doctors.drID AND area.areaID=hospital.areaID AND area.areaID='$catRes2' AND
					hospital.hospitalID=schedule.hospitalID AND schedule.drID=doctors.drID AND schedule.dayNO='$catRes3' ";
		}
	elseif($_POST['catData'] === "null")
		{
			$query = "SELECT DISTINCT drNAME FROM doctors, specialization, area, hospital, schedule WHERE 
					schedule.drID=doctors.drID AND area.areaID='$catRes2' and  schedule.drID= doctors.drID AND 
					schedule.hospitalID ='$catRes1' AND area.areaID=hospital.areaID AND hospital.hospitalID
					=schedule.hospitalID AND schedule.drID=doctors.drID AND schedule.dayNO='$catRes3' ";
		}
	else
		{
			$query = "SELECT DISTINCT drNAME FROM doctors, specialization, area, hospital, schedule WHERE 
				specialization.categoryID=doctors.categoryID AND specialization.categoryID ='$catRes' and schedule.hospitalID
				='$catRes1' AND schedule.drID= doctors.drID AND area.areaID=hospital.areaID AND area.areaID='$catRes2'
				AND hospital.hospitalID=schedule.hospitalID AND schedule.drID=doctors.drID AND schedule.dayNO='$catRes3'";
		}
?>
<body>
		<div class="col-md-3"></div>
		<div class="col-md-6">
            <table class="table table-striped table-bordered table-hover table-responsive">
				<?php $result = mysqli_query($link, $query); ?>
			    <tr>
                    <th style=" text-align: center"> Doctors Name </th>
                </tr>
				<tr>			
		<?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <td style=" text-align: center">
						<a href="pass.php?link=<?php echo $row['drNAME'];?>"> <?php echo $row['drNAME'];?> </a><br>
					</td>
                </tr>
			
		<?php endwhile; ?>
            </table>
        </div>
	</body>
</html>