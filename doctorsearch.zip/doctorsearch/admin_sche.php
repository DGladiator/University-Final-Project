<title> Schedule </title>
<?php
include 'admin_header.php';
session_start();
  if (!isset($_SESSION['login_user'])) {
    header("location:loginView.php");
}
$query = "SELECT * FROM doctors ORDER BY doctors.drID DESC";
$query1 = "SELECT * FROM days ";
$query2 = "SELECT * FROM hospital ";
?>

<div class="col-md-2"> </div>
<div class="container-fluid">

    <div class="row form_element">
        <div class="col-md-6">
<form action="scheduleinsert.php" method="post">
    <div class="input-group input-group-lg">
        <span class="input-group-addon" id="sizing-addon1"> Doctor ID </span>
        <?php if ($result = mysqli_query($link, $query)): ?>
        <select class="form-control" name="id"  type="text">
        <option> Doctor ID </option>
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
          <option  value="<?php echo $row['drID'] ?>">  <?php echo $row["drNAME"] ?>  </option>
        <?php endwhile; ?>            
        </select>
        <?php endif; ?>
    </div>    

    <div class="input-group input-group-lg">
        <span class="input-group-addon" id="sizing-addon1"> Days </span>
        <?php if ($result = mysqli_query($link, $query1)): ?>
        <select class="form-control" name="day"  type="text">
        <option> Days </option>
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
        <option  value="<?php echo $row['dayNO'] ?>">  <?php echo $row["dayNAME"] ?>  </option>
        <?php endwhile; ?>            
        </select>
        <?php endif; ?>
    </div>    

    <div class="input-group input-group-lg">
        <span class="input-group-addon" id="sizing-addon1"> Start Time </span>
        <input name="start" type="text" class="form-control" placeholder="00:00am/pm" aria-describedby="sizing-addon1">
    </div>

    <div class="input-group input-group-lg">
        <span class="input-group-addon" id="sizing-addon1"> End Time </span>
        <input name="end" type="text" class="form-control" placeholder="00:00am/pm" aria-describedby="sizing-addon1">
    </div>

    <div class="input-group input-group-lg">
        <span class="input-group-addon" id="sizing-addon1"> Hospital </span>
        <?php if ($result = mysqli_query($link, $query2)): ?>
        <select class="form-control" name="hos"  type="text">
        <option> Hospital </option>
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
        <option  value="<?php echo $row['hospitalID'] ?>">  <?php echo $row["hospitalNAME"] ?>  </option>
        <?php endwhile; ?>            
        </select>
        <?php endif; ?>
    </div>    

    <div class="input-group input-group-lg">
        <span class="input-group-addon" id="sizing-addon1"> Room </span>
        <input name="room" type="text" class="form-control" placeholder="room,flore" aria-describedby="sizing-addon1">
    </div>

    <div class="input-group input-group-lg">
        <input type="submit" value="submit" class="form-control" placeholder="Username" aria-describedby="sizing-addon1"> 
    </div>
</form>
</div>
</div>
</div>

<br>
<div class="col-md-8"> </div>
<div class="col-md-4"> <a href = "logout.php">Sign Out</a> </div>

</body>
</html>