<?php
	include 'admin_doctor_header.php';
	$catRes = $_POST['catData'];
	$catRes1 = $_POST['catData1'];
	$catRes2 = $_POST['catData2'];
?>
<br>
<?php if(empty($_POST['catData1']=== $row['hospitalID'])): 
$query = "SELECT DISTINCT drNAME FROM doctors where 1";	?> 
	<div class="col-md-4">
        <table class="table table-striped table-bordered table-hover table-responsive" >
			<?php $result = mysqli_query($link, $query); ?>
                <tr>
                    <th style=" text-align: center"> Doctors Name </th>
                </tr>
				<?php while ($row = mysqli_fetch_assoc($result)):?>	
                <tr>
                    <td style=" text-align: center">
                    <?php echo $row["drNAME"];?> <a href="pass.php?link=<?php echo $row['drNAME'];?>"> See More </a>
                    </td>
				<?php endwhile;?>
                </tr>
            </table>	
        </div>	
		<?php endif;?>		
</body>
</html>