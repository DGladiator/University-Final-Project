<?php
	include 'admin_doctor_header.php';
	$num = $_GET['link'];
	$query = "SELECT DISTINCT drNAME,details,contact FROM doctors where drNAME = '$num'";
	$result = mysqli_query($link, $query);
?>
<br>
<div class="col-md-2"> </div>
<div class="col-md-8">
    <table class="table table-striped table-bordered table-hover table-responsive">
		<?php $result = mysqli_query($link, $query); ?> <br>
        <tr>
            <th style=" text-align: center"> Doctors Name </th>
			<th style=" text-align: center"> Details </th>
			<th style=" text-align: center"> Contact </th>
			<th style=" text-align: center"> Schedule </th>
        </tr>
        <tr>
			<?php while ($row = mysqli_fetch_assoc($result)):?>	
            <td><?php echo $row["drNAME"];?></td>
			<td><?php echo $row["details"];?></td>
			<td><?php echo $row["contact"];?></td>
			<td><a href="schedule.php?link=<?php echo $row['drNAME'];?>"> Day & Time </a></td>
        </tr>
        	<?php endwhile;?>
    </table>
</div>
</body>
</html>