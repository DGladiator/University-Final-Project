<title> Update Schedule </title>
<?php
    include 'admin_header.php';
    session_start();
    if (!isset($_SESSION['login_user'])) {
        header("location:loginView.php");
    }
    $num = $_GET['link'];
    $query = "SELECT * FROM schedule  where scheduleNO='$num'";
    $result = mysqli_query($link, $query);
    while ($row = mysqli_fetch_assoc($result)) {
        $sche = $row['scheduleNO'];
        $drid = $row['drID'];
        $hos = $row['hospitalID'];
        $room = $row['room'];
        $start = $row['startTIME'];
        $end = $row['endTIME'];
        }
?>

<div class="container-fluid">
    <div class="row form_element">
	<div class="col-md-2"> </div>
        <div class="col-md-6">
            <form action="" method="post">
                <div class="input-group input-group-lg">
                    <span class="input-group-addon" id="sizing-addon1"> Doctor ID </span>
                    <input name="id" type="text" class="form-control" value="<?php echo $drid; ?>" aria-describedby="sizing-addon1">
                </div>
                <div class="input-group input-group-lg">
                    <span class="input-group-addon" id="sizing-addon1"> Hospital </span>
                    <input name="name" type="text" class="form-control" value="<?php echo $hos; ?>" aria-describedby="sizing-addon1">
                </div>

                <div class="input-group input-group-lg">
                    <span class="input-group-addon" id="sizing-addon1"> Room </span>
                    <input name="contact" type="text" class="form-control" value="<?php echo $room; ?>" aria-describedby="sizing-addon1">
                </div>

                <div class="input-group input-group-lg">
                    <span class="input-group-addon" id="sizing-addon1"> Start Time </span>
                    <input name="details" type="text" class="form-control" value="<?php echo $start; ?>" aria-describedby="sizing-addon1">
                </div>
				
                <div class="input-group input-group-lg">
                    <span class="input-group-addon" id="sizing-addon1"> End Time </span>
                    <input name="details" type="text" class="form-control" value="<?php echo $end; ?>" aria-describedby="sizing-addon1">
                </div>

				<div class="input-group input-group-lg">
                    <input type="submit" value="submit" class="form-control" placeholder="Username" aria-describedby="sizing-addon1"> 
                </div>				
            </div>
            </form>
        </div>

</div>
</body>
</html>